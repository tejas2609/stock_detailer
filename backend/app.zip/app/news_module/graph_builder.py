from sklearn.metrics.pairwise import cosine_similarity


def build_article_graph(narratives, model):

    nodes = []
    links = []

    for narrative in narratives:

        articles = narrative["articles"]

        article_texts = [
            article["normalized_text"]
            for article in articles
        ]

        embeddings = model.encode(
            article_texts
        )

        for article in articles:

            nodes.append({
                "id": article["id"],
                "title": article["title"],
                "source": article["source"],
                "published_at": article["published_at"],
                "cluster_id": narrative["cluster_id"],
                "type": "article"
            })

        similarity_matrix = cosine_similarity(
            embeddings
        )

        for i in range(len(articles)):
            for j in range(i + 1, len(articles)):

                score = similarity_matrix[i][j]

                if score >= 0.72:

                    links.append({
                        "source": articles[i]["id"],
                        "target": articles[j]["id"],
                        "relation": "related",
                        "weight": round(
                            float(score),
                            2
                        )
                    })

    return {
        "nodes": nodes,
        "links": links
    }