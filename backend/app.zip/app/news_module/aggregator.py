import feedparser
import hashlib

from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from news_module.clustering import cluster_articles


def clean_html(raw_html: str) -> str:
    soup = BeautifulSoup(raw_html, "html.parser")
    return soup.get_text(separator=" ", strip=True)


def generate_article_id(title: str, source: str) -> str:
    unique = f"{title}-{source}"
    return hashlib.md5(unique.encode()).hexdigest()


def getNews():
    company = "Tata Power"

    query = quote_plus(f"{company} when:1d")

    url = (
        f"https://news.google.com/rss/search?"
        f"q={query}&hl=en-IN&gl=IN&ceid=IN:en"
    )

    feed = feedparser.parse(url)

    seen = set()

    articles = []

    for art in feed.entries:

        title = art.title.strip()

        source = (
            art.source.title.strip()
            if "source" in art
            else "Google News"
        )

        summary = clean_html(art.summary)

        article_id = generate_article_id(title, source)

        # Deduplicate
        if article_id in seen:
            continue

        seen.add(article_id)

        normalized_text = f"{title}. {summary}"

        articles.append({
            "id": article_id,
            "title": title,
            "source": source,
            "published_at": art.published,
            "url": art.link,
            "summary": summary,
            "normalized_text": normalized_text
        })

    cluster_articles(articles)