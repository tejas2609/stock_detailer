import re
from collections import defaultdict, Counter

import spacy
from sentence_transformers import SentenceTransformer
from sklearn.cluster import DBSCAN

from ai.gather import enrich_graph_links
from news_module.theme_generator import generate_theme
from news_module.graph_builder import build_article_graph


nlp = spacy.load("en_core_web_sm")
model = SentenceTransformer("all-MiniLM-L6-v2")


INVALID_TERMS = {
    "summary",
    "launches",
    "reaches",
    "daily",
    "news",
    "com",
    "etenergyworld",
    "pioneer"
}


def cluster_articles(articles):

    texts = [
        article["normalized_text"]
        for article in articles
    ]

    embeddings = model.encode(texts)

    clustering = DBSCAN(
        eps=0.35,
        min_samples=2,
        metric="cosine"
    )

    labels = clustering.fit_predict(embeddings)

    clustered_data = []

    for idx, label in enumerate(labels):
        clustered_data.append({
            "article_id": articles[idx]["id"],
            "cluster_id": int(label)
        })

    narratives = build_narratives(
        articles,
        clustered_data
    )

    return narratives


def build_narratives(articles, clustered_data):

    article_map = {
        article["id"]: article
        for article in articles
    }

    grouped = defaultdict(list)

    for item in clustered_data:
        grouped[item["cluster_id"]].append(
            article_map[item["article_id"]]
        )

    narratives = []

    for cluster_id, cluster_articles in grouped.items():

        if cluster_id == -1:
            continue

        cluster_context = build_cluster_context(
            cluster_articles
        )

        cleaned_entities = extract_cluster_entities(
            cluster_context
        )

        theme = generate_theme(
            cluster_articles,
            cleaned_entities
        )
        print(theme)
        narrative = {
            "cluster_id": cluster_id,
            "theme": theme,
            "article_count": len(cluster_articles),
            "entities": cleaned_entities,
            "articles": cluster_articles
        }

        narratives.append(narrative)
    
    pre_graph = build_article_graph(narratives, model)
    
    graph = enrich_graph_links(pre_graph)

    
    obj = {
        "company": 'Tata Power',
        "meta": {
            "total_narratives": len(narratives),
            "total_articles": len(graph["nodes"]),
            "total_relationships": len(graph["links"])
        },
        "nodes": graph["nodes"],
        "links": graph["links"]
    }
    print(obj)


def build_cluster_context(cluster_articles):

    parts = []

    for article in cluster_articles:

        title = article.get("title", "")
        summary = article.get("summary", "")

        text = f"""
        Title: {title}
        Summary: {summary}
        """

        parts.append(text.strip())

    return "\n\n".join(parts)


def clean_entity(entity: str):

    entity = entity.strip()

    entity = re.sub(r"http\S+", "", entity)

    entity = re.sub(
        r"[^a-zA-Z\s\-]",
        " ",
        entity
    )

    entity = re.sub(
        r"\s+",
        " ",
        entity
    ).strip()

    words = []

    for word in entity.split():

        if word.lower() in INVALID_TERMS:
            continue

        if any(char.isdigit() for char in word):
            continue

        words.append(word)

    cleaned_entity = " ".join(words)

    if len(cleaned_entity) < 3:
        return None

    return cleaned_entity


def extract_cluster_entities(cluster_context):

    doc = nlp(cluster_context)

    entities = []

    for ent in doc.ents:

        if ent.label_ in [
            "ORG",
            "GPE",
            "PRODUCT"
        ]:

            cleaned = clean_entity(
                ent.text
            )

            if cleaned:
                entities.append(cleaned)

    entity_counter = Counter(entities)

    return entity_counter.most_common(10)