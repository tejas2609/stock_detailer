from dotenv import load_dotenv
import os, json
from groq import Groq

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

VALID_RELATIONS = [
    "expands",
    "announces",
    "operates_in",
    "partners_with",
    "supports",
    "invests_in",
    "related"
]


def label_relationship(article_a, article_b):

    prompt = f"""
        You are a financial news relationship classifier.

        Article A:
        {article_a['title']}

        Article B:
        {article_b['title']}

        Choose ONLY ONE strongest relationship from:

        {VALID_RELATIONS}

        Return JSON only:

        {{
        "relation": ""
        }}
    """

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    result = json.loads(
        response.choices[0].message.content
    )

    return result["relation"]

def enrich_graph_links(graph):

    article_map = {
        node["id"]: node
        for node in graph["nodes"]
    }

    for link in graph["links"]:

        source_article = article_map[
            link["source"]
        ]

        target_article = article_map[
            link["target"]
        ]

        relation = label_relationship(
            source_article,
            target_article
        )

        link["relation"] = relation

    return graph