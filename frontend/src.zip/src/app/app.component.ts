import {
  Component,
  OnInit,
  Input,
  ElementRef,
  ViewChild,
  OnChanges,
  SimpleChanges,
  AfterViewInit,
} from '@angular/core';
import { RouterOutlet } from '@angular/router';
import * as d3 from 'd3';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, AfterViewInit {
  resp = {
    company: 'Tata Power',
    meta: { total_narratives: 2, total_articles: 11, total_relationships: 12 },
    nodes: [
      {
        id: '4328478a157ad5d32859623dbae4993c',
        title:
          'Tata Power Solar Rooftop launches campaign to accelerate solar energy adoption in UP - Moneycontrol.com',
        source: 'Moneycontrol.com',
        published_at: 'Fri, 29 May 2026 17:17:02 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: '00558ccd454b68a52f9d6ec0da209a43',
        title:
          'Tata Power solar targets 3 lakh rooftop installations in UP, eyes 12–15% market share - The Times of India',
        source: 'The Times of India',
        published_at: 'Fri, 29 May 2026 16:23:00 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: '9b2cb8d6dc6636221e6616f165f5db91',
        title:
          'Tata Power-DDL Crosses 10,000 Rooftop Solar Installations, Reaches 160.3 MWp - Saur Energy',
        source: 'Saur Energy',
        published_at: 'Fri, 29 May 2026 06:52:46 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: '1f998e164961f81e956732e5e8962190',
        title:
          'Tata Power-DDL Crosses 10,000 Rooftop Solar Installations Under Project Suryansh - Daily Pioneer',
        source: 'Daily Pioneer',
        published_at: 'Fri, 29 May 2026 05:52:56 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: 'eb270268102c5ee9bb5bd5e0948628c7',
        title:
          'Tata Power Launches ‘Ghar Ghar Solar’ in Lucknow to Push 3 Lakh Rooftop Installations in UP - outlookbusiness.com',
        source: 'outlookbusiness.com',
        published_at: 'Fri, 29 May 2026 12:35:23 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: '11191a0eff776d4f1b172ae191bdb8f1',
        title:
          'Tata Power-DDL crosses 10,000 rooftop solar installations - MillenniumPost',
        source: 'MillenniumPost',
        published_at: 'Thu, 28 May 2026 18:53:03 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: 'a625e06b987274e09d3f85294b7c5e8f',
        title:
          'Rooftop solar adoption surges in Delhi as subsidies, awareness drives boost installations: Tata Power-DDL - ETEnergyworld.com',
        source: 'ETEnergyworld.com',
        published_at: 'Fri, 29 May 2026 03:09:20 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: '3995c86133c4e395c3caf8a54b3df4fd',
        title:
          'Delhi sees surge in rooftop solar adoption amid subsidies awareness drives | The Business Guardian - newspaper - Magzter',
        source: 'Magzter',
        published_at: 'Fri, 29 May 2026 07:59:23 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: 'f03d5555a58091ed5d35fa468068f47a',
        title:
          'Tata Power to make UP a Solar Energy Hub; Launches ‘Ghar Ghar Solar’ Campaign in Lucknow - businessnewsthisweek.com',
        source: 'businessnewsthisweek.com',
        published_at: 'Fri, 29 May 2026 10:45:38 GMT',
        cluster_id: 0,
        type: 'article',
      },
      {
        id: 'bb8b295f7efbe7c4d40ddcf2c16e4ad6',
        title:
          'Dividends, bonuses and stock splits in June 2026: Reliance Industries, HDFC Bank, Infosys, LIC, Tata Steel, Adani Ports, others in focus - Upstox',
        source: 'Upstox',
        published_at: 'Fri, 29 May 2026 06:34:48 GMT',
        cluster_id: 1,
        type: 'article',
      },
      {
        id: '1a7ccdfb779a746e2fa64f3afccbdfaa',
        title:
          'Upcoming Dividend, Bonus Issue, Stock Split In June 2026: Infosys, Reliance, HDFC Bank, HUL, PNB, Tata Steel - Goodreturns',
        source: 'Goodreturns',
        published_at: 'Fri, 29 May 2026 13:21:36 GMT',
        cluster_id: 1,
        type: 'article',
      },
    ],
    links: [
      {
        source: '4328478a157ad5d32859623dbae4993c',
        target: '00558ccd454b68a52f9d6ec0da209a43',
        relation: 'announces',
        weight: 0.78,
      },
      {
        source: '4328478a157ad5d32859623dbae4993c',
        target: 'a625e06b987274e09d3f85294b7c5e8f',
        relation: 'supports',
        weight: 0.73,
      },
      {
        source: '4328478a157ad5d32859623dbae4993c',
        target: 'f03d5555a58091ed5d35fa468068f47a',
        relation: 'announces',
        weight: 0.73,
      },
      {
        source: '00558ccd454b68a52f9d6ec0da209a43',
        target: '9b2cb8d6dc6636221e6616f165f5db91',
        relation: 'expands',
        weight: 0.77,
      },
      {
        source: '00558ccd454b68a52f9d6ec0da209a43',
        target: '1f998e164961f81e956732e5e8962190',
        relation: 'operates_in',
        weight: 0.73,
      },
      {
        source: '00558ccd454b68a52f9d6ec0da209a43',
        target: '11191a0eff776d4f1b172ae191bdb8f1',
        relation: 'expands',
        weight: 0.73,
      },
      {
        source: '9b2cb8d6dc6636221e6616f165f5db91',
        target: '1f998e164961f81e956732e5e8962190',
        relation: 'announces',
        weight: 0.9,
      },
      {
        source: '9b2cb8d6dc6636221e6616f165f5db91',
        target: '11191a0eff776d4f1b172ae191bdb8f1',
        relation: 'operates_in',
        weight: 0.91,
      },
      {
        source: '1f998e164961f81e956732e5e8962190',
        target: '11191a0eff776d4f1b172ae191bdb8f1',
        relation: 'announces',
        weight: 0.91,
      },
      {
        source: 'eb270268102c5ee9bb5bd5e0948628c7',
        target: 'f03d5555a58091ed5d35fa468068f47a',
        relation: 'announces',
        weight: 0.91,
      },
      {
        source: 'a625e06b987274e09d3f85294b7c5e8f',
        target: '3995c86133c4e395c3caf8a54b3df4fd',
        relation: 'supports',
        weight: 0.83,
      },
      {
        source: 'bb8b295f7efbe7c4d40ddcf2c16e4ad6',
        target: '1a7ccdfb779a746e2fa64f3afccbdfaa',
        relation: 'related',
        weight: 0.89,
      },
    ],
  };
  data: any;
  @ViewChild('graphContainer', { static: true })
  treeContainer!: ElementRef;

  ngOnInit() {
    this.data = {
      nodes: this.resp.nodes,
      links: this.resp.links,
      company: this.resp.company,
    };
  }

  ngAfterViewInit() {
    this.renderGraph();
  }

  renderGraph() {
    d3.select(this.treeContainer.nativeElement).selectAll('*').remove();

    const treeData = this.buildTree(this.data);

    const width = 2000;
    const height = 900;

    const svg = d3
      .select(this.treeContainer.nativeElement)
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .style('background', '#ffffff');

    const g = svg.append('g').attr('transform', 'translate(100,50)');

    const root = d3.hierarchy(treeData);

    const treeLayout = d3.tree<any>().size([height - 100, width - 350]);

    const tooltip = d3
      .select('body')
      .append('div')
      .style('position', 'absolute')
      .style('background', '#1f2937')
      .style('color', '#fff')
      .style('padding', '12px 16px')
      .style('border-radius', '12px')
      .style('font-size', '13px')
      .style('max-width', '320px')
      .style('pointer-events', 'none')
      .style('opacity', 0)
      .style('box-shadow', '0 8px 24px rgba(0,0,0,0.35)');

    treeLayout(root);

    /*
   LINKS
  */
    g.selectAll('.link')
      .data(root.links())
      .enter()
      .append('path')
      .attr(
        'd',
        d3
          .linkHorizontal<any, any>()
          .x((d: any) => d.y)
          .y((d: any) => d.x),
      )
      .attr('fill', 'none')
      .attr('stroke', '#4b5563')
      .attr('stroke-width', 1.5);

    /*
   NODES
  */
    const node = g
      .selectAll('.node')
      .data(root.descendants())
      .enter()
      .append('g')
      .attr('transform', (d: any) => `translate(${d.y},${d.x})`);

    /*
   CIRCLE
  */
    node
      .append('circle')
      .attr('r', (d: any) => {
        if (d.depth === 0) return 8;
        if (d.depth === 1) return 6;

        return 4;
      })
      .attr('fill', (d: any) => {
        if (d.depth === 0) return '#f59e0b';
        if (d.depth === 1) return '#3b82f6';

        return '#000000';
      });

    /*
   LABELS
  */
    node
      .append('text')
      .text((d: any) => {
        if (d.depth === 0) return d.data.name;

        return d.data.name.length > 50
          ? d.data.name.slice(0, 50) + '...'
          : d.data.name;
      })
      .attr('dy', 4)
      .attr('x', (d: any) => (d.children ? -12 : 12))
      .style('text-anchor', (d: any) => (d.children ? 'end' : 'start'))
      .style('fill', '#000')
      .style('font-size', '12px');

    /*
   CLICK EVENT
  */
    node.on('click', (_, d: any) => {
      console.log('clicked node:', d.data);
    });

    node
      .on('mouseenter', function (event: any, d: any) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('transform', `translate(${d.y},${d.x}) scale(1.25)`);

        tooltip.transition().duration(150).style('opacity', 1);

        tooltip
          .html(
            `
        <div style="font-weight:600; line-height:1.5;">
          ${d.data.name}
        </div>
      `,
          )
          .style('left', event.pageX + 15 + 'px')
          .style('top', event.pageY - 20 + 'px');
      })

      .on('mousemove', function (event: any) {
        tooltip
          .style('left', event.pageX + 15 + 'px')
          .style('top', event.pageY - 20 + 'px');
      })

      .on('mouseleave', function (event: any, d: any) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('transform', `translate(${d.y},${d.x}) scale(1)`);

        tooltip.transition().duration(150).style('opacity', 0);
      });

    /*
   ZOOM + PAN
  */
    svg.call(
      d3
        .zoom<any, any>()
        .scaleExtent([0.5, 3])
        .on('zoom', (event) => {
          g.attr('transform', event.transform);
        }),
    );
  }

  buildTree(data: any) {
    const nodeMap = new Map();

    /*
   Create all article nodes
  */
    data.nodes.forEach((node: any) => {
      nodeMap.set(node.id, {
        name: node.title,
        id: node.id,
        children: [],
      });
    });

    /*
   Build relationships from links
  */
    const childIds = new Set();

    data.links.forEach((link: any) => {
      const sourceNode = nodeMap.get(link.source);
      const targetNode = nodeMap.get(link.target);

      if (sourceNode && targetNode) {
        sourceNode.children.push(targetNode);
        childIds.add(link.target);
      }
    });

    /*
   Find all top-level article roots
   (articles which are never targets)
  */
    const rootArticles = data.nodes
      .filter((node: any) => !childIds.has(node.id))
      .map((node: any) => nodeMap.get(node.id));

    /*
   Company becomes level 0 root
  */
    return {
      name: data.company,
      children: rootArticles,
    };
  }
}
